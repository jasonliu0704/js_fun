(function() {

  var EditingEntryView = {};

  /* Renders a view to allow the user to edit an entry. Requires the $entry
   * element and an object representing the active entry. */
  EditingEntryView.render = function($entry, activeEntryData) {
    // TODO
  };

  window.EditingEntryView = EditingEntryView;

})();
