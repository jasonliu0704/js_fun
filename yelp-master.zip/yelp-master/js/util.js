(function() {

  var Util = {};

  // TODO for any common code across files

  window.Util = Util;

})();
