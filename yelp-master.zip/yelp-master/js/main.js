(function() {

  /* MainView handles all the logic. */
  $(document).ready(function() {
    MainView.render($(document.body));
  });

})();
