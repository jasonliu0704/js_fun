(function() {

  var GoogleMapView = {};

  // zoom level for Google Map
  var DEFAULT_ZOOM = 14;
  var STATUS_OK = 200;

  /* Renders a map for the given entry into the provided $map element. */
  GoogleMapView.render = function($map, entryData) {
    // TODO
  };

  window.GoogleMapView = GoogleMapView;

})();
