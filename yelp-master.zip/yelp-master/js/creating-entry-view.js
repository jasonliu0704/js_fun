(function() {

  var CreatingEntryView = {};

  /* Renders a view to allow the user to create an entry. Requires the $entry
   * element. */
  CreatingEntryView.render = function($entry) {
    // TODO
  };

  window.CreatingEntryView = CreatingEntryView;

})();
